from random import randint
from random import uniform # Random float:  2.5 <= x < 10.0
from sys import maxsize
import itertools
import csv


def save_in_csv_file(length,matrix):
    _name_file_csv = "output_{}.csv".format(length)
    with open(_name_file_csv, 'w') as csvfile:
        _field_names = []
        _field_names.append("Test Case")
        for i in range(length):
            _field_names.append("Variable "+str(i+1))
        writer = csv.DictWriter(csvfile, fieldnames=_field_names)
        writer.writeheader()
        i = 0
        for t in matrix:
            row = {}
            i += 1
            row.update({'Test Case': i})
            for j in range(len(t)):
                row.update({_field_names[j+1]: t[j]})
            writer.writerow(row)



minsize = -maxsize + 1
_num_variable = 0;
_threshold_variables = {}
_num_variable = eval(input("Please Enter Number Variable: "))
for i in range(_num_variable):
    _min = eval(input("Please Enter Min Variable {}: ".format(i+1)))
    _max = eval(input("Please Enter Max Variable {}: ".format(i+1)))
    _threshold_variables.update({str(i+1): [_min, _max]})


_state_case =[]
_state_template = []
for i in _threshold_variables.keys():
    _case = []
    _l_min = _threshold_variables[i][0]
    _l_max = _threshold_variables[i][1]
    _state_template.append(['v','nv1','nv2'])
    _case.append(randint(_l_min,_l_max))
    _case.append(randint(minsize,_l_min-1))
    _case.append(randint(_l_max+1,maxsize))
    _state_case.append(_case)

matrix = itertools.product(*_state_case)

save_in_csv_file(_num_variable, matrix)

for case in itertools.product(*_state_template):
    print(case)

