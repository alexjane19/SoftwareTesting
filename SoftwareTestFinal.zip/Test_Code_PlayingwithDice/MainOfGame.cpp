#include<iostream>
#include "Game.h"
using namespace std;
int main()
{
	Game Game1;
	Game1.startGame();
	//system("pause");
	return 0;

}
