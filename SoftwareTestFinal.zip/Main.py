from random import randint
from random import uniform # Random float:  2.5 <= x < 10.0
from sys import maxsize
import itertools
import csv

keys = ["n", "m", "p"]
minsize = -maxsize + 1


def save_in_csv_file(length,matrix):
    print("\n")
    print(length)
    _name_file_csv = "output_{}.csv".format(length)
    with open(_name_file_csv, 'w') as csvfile:
        _field_names = []
        _field_names.append("Test Case")
        for i in keys:
            _field_names.append(i)
        writer = csv.DictWriter(csvfile, fieldnames=_field_names)
        writer.writeheader()
        i = 0
        for t in matrix:
            row = {}
            i += 1
            row.update({'Test Case': i})
            print('Test Case {}'.format(i))
            for j in range(len(t)):
                row.update({_field_names[j+1]: t[j]})
                print(t[j])
            writer.writerow(row)


_num_variable = 0;
_threshold_variables = {}


_min = eval(input("Please Enter Min rows and columns : "))
_max = eval(input("Please Enter Max rows and columns : "))
_threshold_variables.update({str(keys[_num_variable]): [_min, _max]})
_num_variable+=1


_min = eval(input("Please Enter Min Players : "))
_max = eval(input("Please Enter Max Players : "))
_threshold_variables.update({str(keys[_num_variable]): [_min, _max]})
_num_variable+=1


_min = eval(input("Please Enter Min traps : "))
# _max = eval(input("Please Enter Max traps : "))
_threshold_variables.update({str(keys[_num_variable]): [_min, 0]})
_num_variable+=1

def test_EC():
    _state_case =[]
    _state_template = []
    for i in keys:
        _case = []
        _l_min = _threshold_variables[i][0]
        if i == "p":
            _l_max = _state_case[0][0]
        else:
            _l_max = _threshold_variables[i][1]
        _state_template.append(['v','nv1','nv2'])
        _case.append(randint(_l_min,_l_max))
        _case.append(randint(minsize,_l_min-1))
        _case.append(randint(_l_max+1,maxsize))
        _state_case.append(_case)

    matrix = itertools.product(*_state_case)


    save_in_csv_file("EC", matrix)

def test_BVA():
    _state_case =[]
    for i in keys:
        _case = []
        _l_min = _threshold_variables[i][0]
        if i == "p":
            _l_max = _state_case[0][2]
        else:
            _l_max = _threshold_variables[i][1]

        _case.append(_l_min)
        _case.append(_l_min+1)
        _case.append(int((_l_min+_l_max)/2))
        _case.append(_l_max-1)
        _case.append(_l_max)
        _state_case.append(_case)


    # print(_state_case)
    _bva_case = []
    for i in range(len(_state_case)):
        for j in _state_case[i]:
            _case = []
            if i==0:
                _case.append(j)
                _case.append(_state_case[i+1][2])
                _case.append(_state_case[i+2][2])
                _bva_case.append(_case)
            if i==1:
                _case.append(_state_case[i-1][2])
                _case.append(j)
                _case.append(_state_case[i+1][2])
                _bva_case.append(_case)
            if i==2:
                _case.append(_state_case[i-2][2])
                _case.append(_state_case[i-1][2])
                _case.append(j)
                _bva_case.append(_case)

    # print(_bva_case)

    # matrix = itertools.product(*_state_case)


    save_in_csv_file("BVA", _bva_case)


def test_STH():
    _state_case =[]
    for i in keys:
        _case = []
        _l_min = _threshold_variables[i][0]
        if i == "p":
            _l_max = _state_case[0][3]
        else:
            _l_max = _threshold_variables[i][1]
        _case.append(_l_min-1)
        _case.append(_l_min)
        _case.append(_l_min+1)
        _case.append(int((_l_min+_l_max)/2))
        _case.append(_l_max-1)
        _case.append(_l_max)
        _case.append(_l_max+1)

        _state_case.append(_case)


    print(_state_case)
    _bva_case = []
    for i in range(len(_state_case)):
        for j in _state_case[i]:
            _case = []
            if i==0:
                _case.append(j)
                _case.append(_state_case[i+1][3])
                _case.append(_state_case[i+2][3])
                _bva_case.append(_case)
            if i==1:
                _case.append(_state_case[i-1][3])
                _case.append(j)
                _case.append(_state_case[i+1][3])
                _bva_case.append(_case)
            if i==2:
                _case.append(_state_case[i-2][3])
                _case.append(_state_case[i-1][3])
                _case.append(j)
                _bva_case.append(_case)

    print(_bva_case)

    # matrix = itertools.product(*_state_case)


    save_in_csv_file("STH", _bva_case)


def test_WST():
    _state_case =[]
    for i in keys:
        _case = []
        _l_min = _threshold_variables[i][0]
        if i == "p":
            _l_max = _state_case[0][2]
        else:
            _l_max = _threshold_variables[i][1]

        _case.append(_l_min)
        _case.append(_l_min+1)
        _case.append(int((_l_min+_l_max)/2))
        _case.append(_l_max-1)
        _case.append(_l_max)
        _state_case.append(_case)


    # print(_state_case)
    # _bva_case = []
    # for i in range(len(_state_case)):
    #     for j in _state_case[i]:
    #         _case = []
    #         if i==0:
    #             _case.append(j)
    #             _case.append(_state_case[i+1][2])
    #             _case.append(_state_case[i+2][2])
    #             _bva_case.append(_case)
    #         if i==1:
    #             _case.append(_state_case[i-1][2])
    #             _case.append(j)
    #             _case.append(_state_case[i+1][2])
    #             _bva_case.append(_case)
    #         if i==2:
    #             _case.append(_state_case[i-2][2])
    #             _case.append(_state_case[i-1][2])
    #             _case.append(j)
    #             _bva_case.append(_case)

    # print(_bva_case)

    matrix = itertools.product(*_state_case)


    save_in_csv_file("WST", matrix)


def test_WST_STG():
    _state_case =[]
    for i in keys:
        _case = []
        _l_min = _threshold_variables[i][0]
        if i == "p":
            _l_max = _state_case[0][3] #            _l_max = _state_case[0][3]**2
        else:
            _l_max = _threshold_variables[i][1]
        _case.append(_l_min-1)
        _case.append(_l_min)
        _case.append(_l_min+1)
        _case.append(int((_l_min+_l_max)/2))
        _case.append(_l_max-1)
        _case.append(_l_max)
        _case.append(_l_max+1)
        _state_case.append(_case)


    matrix = itertools.product(*_state_case)

    save_in_csv_file("WST_STG", matrix)


test_BVA()
test_STH()
test_WST()
test_WST_STG()
test_EC()

#
# for case in itertools.product(*_state_template):
#     print(case)
#
